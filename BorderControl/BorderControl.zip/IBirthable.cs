﻿namespace BorderControl
{
    using System;
    public interface IBirthable
    {
        string Name { get; set; }
        string Birthday { get; set; }
    }
}
