﻿namespace PersonInfo
{
    using System;
    public interface IBirthable
    {
        string Birthdate { get; set; }
    }
}
