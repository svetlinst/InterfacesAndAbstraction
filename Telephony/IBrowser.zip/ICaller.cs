﻿namespace Telephony
{
    public interface ICaller
    {
        string CallPhonenumber(string number);
    }
}
